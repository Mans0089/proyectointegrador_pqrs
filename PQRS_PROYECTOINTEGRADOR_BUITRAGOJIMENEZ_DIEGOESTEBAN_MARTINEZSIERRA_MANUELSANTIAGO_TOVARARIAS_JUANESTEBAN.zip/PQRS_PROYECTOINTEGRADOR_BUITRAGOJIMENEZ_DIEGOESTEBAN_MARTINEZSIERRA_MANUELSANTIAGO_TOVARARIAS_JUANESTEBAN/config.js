// Configuración de la base de datos
module.exports = {
    host: 'localhost', // Dirección del servidor de la base de datos
    user: 'root', // Nombre de usuario de la base de datos
    password: '', // Contraseña de la base de datos
    database: 'system_pqrs' // Nombre de la base de datos
};
